class Sinistro:
    def __init__(self, numero_apolice, descricao, data):
        self.numero_apolice = numero_apolice
        self.descricao = descricao
        self.data = data
        self.status = "aberto"
